import { IEnsureAsyncTaskConstrained } from '@lirx/async-task';
import { IAsyncStoreEntry, IGenericAsyncStoreEntry } from '../../types/async-store-entry.type';

export type InferAsyncStoreGetRawValueFromKey<GEntry extends IGenericAsyncStoreEntry, GKey extends string> =
  GEntry extends IAsyncStoreEntry<GKey, infer GValue>
    ? GValue
    : undefined
  ;

export type InferAsyncStoreGetValueFromKey<GEntry extends IGenericAsyncStoreEntry, GKey extends string> =
  IEnsureAsyncTaskConstrained<InferAsyncStoreGetRawValueFromKey<GEntry, GKey>>;

