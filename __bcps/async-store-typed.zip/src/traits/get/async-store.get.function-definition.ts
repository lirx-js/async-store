import { Abortable, AsyncTask } from '@lirx/async-task';
import { IGenericAsyncStoreEntry } from '../../types/async-store-entry.type';
import { InferAsyncStoreGetValueFromKey } from './infer-async-store-get-value-from-key.type';

export interface IAsyncStoreGetFunction<GEntry extends IGenericAsyncStoreEntry> {
  <GKey extends string>(
    key: GKey,
    abortable: Abortable,
  ): AsyncTask<InferAsyncStoreGetValueFromKey<GEntry, GKey>>;
}

