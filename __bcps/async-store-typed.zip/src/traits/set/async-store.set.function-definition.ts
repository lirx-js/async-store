import { Abortable, AsyncTask } from '@lirx/async-task';
import { IGenericAsyncStoreEntry } from '../../types/async-store-entry.type';
import { InferAsyncStoreSetValueFromKey } from './infer-async-store-set-value-from-key.type';

export interface IAsyncStoreSetFunction<GEntry extends IGenericAsyncStoreEntry> {
  <GKey extends string>(
    key: GKey,
    value: InferAsyncStoreSetValueFromKey<GEntry, GKey>,
    abortable: Abortable,
  ): AsyncTask<void>;
}

