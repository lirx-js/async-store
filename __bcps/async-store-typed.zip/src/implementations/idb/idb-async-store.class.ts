import { Abortable, AsyncTask, IAbortableOptions } from '@lirx/async-task';
import { IAsyncStore } from '../../async-store.type';
import { InferAsyncStoreGetValueFromKey } from '../../traits/get/infer-async-store-get-value-from-key.type';
import { InferAsyncStoreSetValueFromKey } from '../../traits/set/infer-async-store-set-value-from-key.type';
import { IGenericAsyncStoreEntry } from '../../types/async-store-entry.type';
import { promisifyIDBRequest } from './helpers/promisify-idb-request';
import { noop } from '@lirx/utils';

/**
 * Doc:
 *
 * https://github.com/jakearchibald/idb-keyval/blob/main/src/index.ts
 */


export interface IIDBAsyncStoreOptions {
  readonly db: IDBDatabase;
  readonly storeName: string;
}

export interface IIDBAsyncStoreOpenOptions extends IAbortableOptions, Omit<IIDBAsyncStoreOptions, 'db' | 'storeName'>, Partial<Pick<IIDBAsyncStoreOptions, 'storeName'>> {
  readonly dbName?: string;
}

export class IDBAsyncStore<GEntry extends IGenericAsyncStoreEntry> implements IAsyncStore<GEntry> {

  static open<GEntry extends IGenericAsyncStoreEntry>(
    {
      dbName = 'async-store',
      storeName = 'keyval',
      abortable,
    }: IIDBAsyncStoreOpenOptions,
  ): AsyncTask<IDBAsyncStore<GEntry>> {
    return AsyncTask.fromFactory((abortable: Abortable): AsyncTask<IDBDatabase> => {
      const request: IDBOpenDBRequest = indexedDB.open(dbName);
      request.onupgradeneeded = () => request.result.createObjectStore(storeName);
      return promisifyIDBRequest<IDBDatabase>(request, abortable);
    }, abortable)
      .successful((db: IDBDatabase): IDBAsyncStore<GEntry> => {
        return new IDBAsyncStore<GEntry>({
          db,
          storeName,
        });
      });

  }

  readonly #db: IDBDatabase;
  readonly #storeName: string;

  constructor(
    {
      db,
      storeName,
    }: IIDBAsyncStoreOptions,
  ) {
    this.#db = db;
    this.#storeName = storeName;
  }

  get<GKey extends string>(
    key: GKey,
    abortable: Abortable,
  ): AsyncTask<InferAsyncStoreGetValueFromKey<GEntry, GKey>> {
    return AsyncTask.fromFactory((abortable: Abortable): AsyncTask<InferAsyncStoreGetValueFromKey<GEntry, GKey>> => {
      return promisifyIDBRequest<InferAsyncStoreGetValueFromKey<GEntry, GKey>>(
        this.#db.transaction(this.#storeName, 'readonly').objectStore(this.#storeName).get(key),
        abortable,
      );
    }, abortable);
  }

  set<GKey extends string>(
    key: GKey,
    value: InferAsyncStoreSetValueFromKey<GEntry, GKey>,
    abortable: Abortable,
  ): AsyncTask<void> {
    return AsyncTask.fromFactory((abortable: Abortable): AsyncTask<IDBValidKey> => {
      return promisifyIDBRequest<IDBValidKey>(
        this.#db.transaction(this.#storeName, 'readwrite').objectStore(this.#storeName).put(value, key),
        abortable,
      );
    }, abortable)
      .successful(noop);
  }

  delete(
    key: string,
    abortable: Abortable,
  ): AsyncTask<void> {
    return AsyncTask.fromFactory((abortable: Abortable): AsyncTask<void> => {
      return promisifyIDBRequest<void>(
        this.#db.transaction(this.#storeName, 'readwrite').objectStore(this.#storeName).delete(key) as IDBRequest<void>,
        abortable,
      );
    }, abortable);
  }

  clear(
    abortable: Abortable,
  ): AsyncTask<void> {
    return AsyncTask.fromFactory((abortable: Abortable): AsyncTask<void> => {
      return promisifyIDBRequest<void>(
        this.#db.transaction(this.#storeName, 'readwrite').objectStore(this.#storeName).clear() as IDBRequest<void>,
        abortable,
      );
    }, abortable);
  }

  // TODO: entries, keys, values
}




