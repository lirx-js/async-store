import { Abortable, AsyncTask } from '@lirx/async-task';
import { IAsyncStore, IGenericAsyncStore } from '../../async-store.type';
import { InferAsyncStoreGetValueFromKey } from '../../traits/get/infer-async-store-get-value-from-key.type';
import { InferAsyncStoreSetValueFromKey } from '../../traits/set/infer-async-store-set-value-from-key.type';
import { IGenericAsyncStoreEntry } from '../../types/async-store-entry.type';
import { decryptDataUsingPassword } from './helpers/decrypt-data-using-password';
import { encryptDataUsingPassword } from './helpers/encrypt-data-using-password';

export interface IPasswordEncryptedAsyncStoreOptions {
  readonly store: IGenericAsyncStore;
  readonly password: string;
}

export class PasswordEncryptedAsyncStore<GEntry extends IGenericAsyncStoreEntry> implements IAsyncStore<GEntry> {
  readonly #store: IGenericAsyncStore;
  readonly #password: string;

  constructor(
    {
      store,
      password,
    }: IPasswordEncryptedAsyncStoreOptions,
  ) {
    this.#store = store;
    this.#password = password;
  }

  get<GKey extends string>(
    key: GKey,
    abortable: Abortable,
  ): AsyncTask<InferAsyncStoreGetValueFromKey<GEntry, GKey>> {
    return this.#store.get(key, abortable)
      .successful((encrypted: Uint8Array): AsyncTask<any> => {
        return decryptDataUsingPassword({
          password: this.#password,
          encrypted,
          abortable,
        });
      });
  }

  set<GKey extends string>(
    key: GKey,
    value: InferAsyncStoreSetValueFromKey<GEntry, GKey>,
    abortable: Abortable,
  ): AsyncTask<void> {
    return encryptDataUsingPassword({
      password: this.#password,
      data: value,
      abortable,
    })
      .successful((encrypted: Uint8Array): AsyncTask<void> => {
        return this.#store.set(key, encrypted, abortable);
      });
  }

  delete(
    key: string,
    abortable: Abortable,
  ): AsyncTask<void> {
    return this.#store.delete(key, abortable);
  }

  clear(
    abortable: Abortable,
  ): AsyncTask<void> {
    return this.#store.clear(abortable);
  }

  // TODO: entries, keys, values
}




