import { IAsyncStoreClearTrait } from './traits/clear/async-store.clear.trait';
import { IAsyncStoreDeleteTrait } from './traits/delete/async-store.delete.trait';
import { IAsyncStoreGetTrait } from './traits/get/async-store.get.trait';
import { IAsyncStoreSetTrait } from './traits/set/async-store.set.trait';
import { IGenericAsyncStoreEntry } from './types/async-store-entry.type';

export interface IAsyncStore<GEntry extends IGenericAsyncStoreEntry> extends //
  IAsyncStoreGetTrait<GEntry>,
  IAsyncStoreSetTrait<GEntry>,
  IAsyncStoreDeleteTrait,
  IAsyncStoreClearTrait
//
{

}

export type IGenericAsyncStore = IAsyncStore<any>;




