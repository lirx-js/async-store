import { IAsyncStoreKeysFunction } from './async-store.keys.function-definition';

export interface IAsyncStoreKeysTrait {
  readonly keys: IAsyncStoreKeysFunction;
}
