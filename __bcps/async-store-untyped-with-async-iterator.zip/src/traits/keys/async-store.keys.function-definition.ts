import { IAsyncTaskIterator } from '../../../async-task-iterator/async-task-iterator.type';

export interface IAsyncStoreKeysFunction {
  (): IAsyncTaskIterator<string>;
}

