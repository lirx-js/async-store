import { IAsyncStoreSetFunction } from './async-store.set.function-definition';

export interface IAsyncStoreSetTrait {
  readonly set: IAsyncStoreSetFunction;
}
