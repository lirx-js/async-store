import { IAsyncTaskIterator } from '../../../async-task-iterator/async-task-iterator.type';

export interface IAsyncStoreValuesFunction {
  (): IAsyncTaskIterator<any>;
}

