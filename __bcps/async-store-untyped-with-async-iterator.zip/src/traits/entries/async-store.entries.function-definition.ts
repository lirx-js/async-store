import { IAsyncTaskIterator } from '../../../async-task-iterator/async-task-iterator.type';

export type IAsyncStoreEntry = readonly [string, any];

export interface IAsyncStoreEntriesFunction {
  (): IAsyncTaskIterator<IAsyncStoreEntry>;
}

