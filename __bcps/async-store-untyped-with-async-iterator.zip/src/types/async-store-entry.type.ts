export type IAsyncStoreEntry<GKey extends string, GValue> = readonly [
  key: GKey,
  value: GValue,
];

export type IGenericAsyncStoreEntry = IAsyncStoreEntry<any, any>;
