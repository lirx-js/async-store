import { IAsyncStoreValuesFunction } from './async-store.values.function-definition';

export interface IAsyncStoreValuesTrait {
  readonly values: IAsyncStoreValuesFunction;
}
