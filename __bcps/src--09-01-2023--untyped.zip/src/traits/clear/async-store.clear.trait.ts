import { IAsyncStoreClearFunction } from './async-store.clear.function-definition';

export interface IAsyncStoreClearTrait {
  readonly clear: IAsyncStoreClearFunction;
}
